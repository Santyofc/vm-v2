"use client";

import { cn } from "@/lib/utils";
import { type ReactNode } from "react";

interface GlowingBoxProps {
  children: ReactNode;
  className?: string;
  /** Color del glow: "blue" | "cyan" | "emerald" | "amber" | "rose" | "violet" */
  color?: "blue" | "cyan" | "emerald" | "amber" | "rose" | "violet";
  /** Intensidad del glow: "sm" | "md" | "lg" */
  intensity?: "sm" | "md" | "lg";
  /** Si true, muestra la línea de gradiente en el top */
  topLine?: boolean;
  /** Si true, el card hace hover con translateY */
  hoverable?: boolean;
}

const COLOR_MAP = {
  blue:    { glow: "rgba(37,99,235,{a})",  line: "var(--color-zs-blue)",    bg: "var(--color-zs-blue-dim)" },
  cyan:    { glow: "rgba(6,182,212,{a})",  line: "var(--color-zs-cyan)",    bg: "var(--color-zs-cyan-dim)" },
  emerald: { glow: "rgba(16,185,129,{a})", line: "var(--color-zs-emerald)", bg: "var(--color-zs-em-dim)"   },
  amber:   { glow: "rgba(245,158,11,{a})", line: "var(--color-zs-amber)",   bg: "var(--color-zs-amb-dim)"  },
  rose:    { glow: "rgba(244,63,94,{a})",  line: "var(--color-zs-rose)",    bg: "var(--color-zs-rose-dim)" },
  violet:  { glow: "rgba(139,92,246,{a})", line: "var(--color-zs-violet)",  bg: "var(--color-zs-vio-dim)"  },
};

const INTENSITY_MAP = {
  sm: "0.18",
  md: "0.28",
  lg: "0.42",
};

export function GlowingBox({
  children,
  className,
  color = "blue",
  intensity = "md",
  topLine = true,
  hoverable = true,
}: GlowingBoxProps) {
  const { glow, line } = COLOR_MAP[color];
  const alpha  = INTENSITY_MAP[intensity];
  const shadow = `0 8px 40px ${glow.replace("{a}", alpha)}, 0 1px 0 rgba(255,255,255,0.06) inset`;

  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-2xl",
        hoverable && "transition-all duration-250 hover:-translate-y-0.5",
        className
      )}
      style={{
        background: "rgba(10,13,24,0.65)",
        backdropFilter: "blur(28px) saturate(1.4)",
        WebkitBackdropFilter: "blur(28px) saturate(1.4)",
        border: `1px solid ${glow.replace("{a}", "0.22")}`,
        boxShadow: shadow,
      }}
    >
      {/* Top gradient line */}
      {topLine && (
        <div
          className="absolute top-0 left-0 right-0 h-[1px]"
          style={{
            background: `linear-gradient(90deg, transparent 0%, ${line} 50%, transparent 100%)`,
            opacity: 0.6,
          }}
        />
      )}

      {children}
    </div>
  );
}

/* ── Variante: KPI Card con acento superior de 2px ── */
interface KpiCardProps {
  label:      string;
  value:      string | number;
  trend?:     string;
  trendUp?:   boolean;
  icon?:      ReactNode;
  accent?:    keyof typeof COLOR_MAP;
  className?: string;
}

export function KpiCard({
  label,
  value,
  trend,
  trendUp = true,
  icon,
  accent = "blue",
  className,
}: KpiCardProps) {
  const { glow, line, bg } = COLOR_MAP[accent];

  return (
    <div
      className={cn("relative overflow-hidden rounded-2xl p-5", className)}
      style={{
        background: "rgba(10,13,24,0.65)",
        backdropFilter: "blur(28px)",
        WebkitBackdropFilter: "blur(28px)",
        border: "1px solid var(--color-zs-border)",
        transition: "all 0.25s ease",
      }}
      onMouseEnter={e => {
        (e.currentTarget as HTMLElement).style.borderColor = glow.replace("{a}", "0.3");
        (e.currentTarget as HTMLElement).style.transform   = "translateY(-2px)";
      }}
      onMouseLeave={e => {
        (e.currentTarget as HTMLElement).style.borderColor = "var(--color-zs-border)";
        (e.currentTarget as HTMLElement).style.transform   = "translateY(0)";
      }}
    >
      {/* Accent line top */}
      <div
        className="absolute top-0 left-0 right-0 h-[2px]"
        style={{ background: `linear-gradient(90deg, transparent, ${line}, transparent)` }}
      />

      <div className="flex items-start justify-between mb-4">
        <p
          className="text-[10px] font-bold tracking-[0.1em] uppercase"
          style={{ color: "var(--color-zs-text-muted)" }}
        >
          {label}
        </p>
        {icon && (
          <div
            className="w-9 h-9 rounded-xl flex items-center justify-center"
            style={{ background: bg }}
          >
            {icon}
          </div>
        )}
      </div>

      <p className="zs-text-display text-3xl font-black tracking-tight text-white mb-3">
        {value}
      </p>

      {trend && (
        <span
          className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-1 rounded-lg"
          style={
            trendUp
              ? { background: "var(--color-zs-em-dim)", color: "var(--color-zs-emerald)" }
              : { background: "var(--color-zs-amb-dim)", color: "var(--color-zs-amber)" }
          }
        >
          {trendUp ? "↑" : "→"} {trend}
        </span>
      )}
    </div>
  );
}

/* ── Variante: Panel con header ── */
interface PanelProps {
  title:      string;
  badge?:     ReactNode;
  action?:    ReactNode;
  children:   ReactNode;
  className?: string;
  noPadding?: boolean;
}

export function Panel({
  title,
  badge,
  action,
  children,
  className,
  noPadding = false,
}: PanelProps) {
  return (
    <div
      className={cn("relative overflow-hidden rounded-2xl", className)}
      style={{
        background: "rgba(10,13,24,0.5)",
        backdropFilter: "blur(20px)",
        WebkitBackdropFilter: "blur(20px)",
        border: "1px solid var(--color-zs-border)",
      }}
    >
      {/* Header */}
      <div
        className="flex items-center justify-between px-5 py-4"
        style={{ borderBottom: "1px solid var(--color-zs-border)" }}
      >
        <div className="flex items-center gap-3">
          <h3 className="zs-text-display font-bold text-[15px] text-white">
            {title}
          </h3>
          {badge}
        </div>
        {action}
      </div>

      {/* Body */}
      <div className={cn(!noPadding && "p-5")}>{children}</div>
    </div>
  );
}
