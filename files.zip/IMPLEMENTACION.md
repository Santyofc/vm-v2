# 🎨 ZonaSur Tech — Guía de Implementación del Rediseño
## Glassmorphism Refinado v3

---

## 📦 Archivos entregados

| Archivo | Destino en tu proyecto |
|---------|------------------------|
| `globals.css` | `app/globals.css` (REEMPLAZA el actual) |
| `GlowingBox.tsx` | `components/ui/GlowingBox.tsx` |
| `login-page.tsx` | `app/login/page.tsx` |
| `register-page.tsx` | `app/registro/page.tsx` |
| `landing-page.tsx` | `app/landing/page.tsx` o `app/page.tsx` |
| `admin-layout.tsx` | `app/admin/layout.tsx` |
| `admin-sidebar.tsx` | `components/admin/sidebar.tsx` |
| `admin-topbar.tsx` | `components/admin/topbar.tsx` |
| `admin-page.tsx` | `app/admin/page.tsx` |
| `tenant-layout.tsx` | `app/(tenant)/layout.tsx` |
| `tenant-sidebar.tsx` | `components/tenant/sidebar.tsx` |
| `tenant-topbar.tsx` | `components/tenant/topbar.tsx` |
| `tenant-page.tsx` | `app/(tenant)/page.tsx` o `app/page.tsx` |

---

## 1️⃣ globals.css — Paso más importante

Reemplaza tu `app/globals.css` completo con el archivo entregado. Este archivo:

- Define **todos los tokens CSS** bajo `@theme` (Tailwind v4)
- Incluye los componentes base: `.zs-card`, `.zs-btn`, `.zs-input`, `.zs-sidebar`, etc.
- Agrega el **grid de fondo** y el **noise grain** al `body`
- Define todas las **animaciones**: `zs-fade-up`, `zs-pulse-dot`, `zs-spin`, shimmer
- Importa las fuentes **Syne** (display) + **DM Sans** (body) vía Google Fonts

### Variables CSS disponibles después de implementar:

```css
/* Colores principales */
var(--color-zs-base)        /* #06080f — fondo base */
var(--color-zs-blue)        /* #2563eb — acento principal */
var(--color-zs-blue-light)  /* #3b82f6 — versión más clara */
var(--color-zs-cyan)        /* #06b6d4 */
var(--color-zs-emerald)     /* #10b981 */
var(--color-zs-amber)       /* #f59e0b */
var(--color-zs-rose)        /* #f43f5e */

/* Superficies glass */
var(--color-zs-surface)     /* rgba(255,255,255,0.03) */
var(--color-zs-surface-md)  /* rgba(255,255,255,0.055) */

/* Bordes */
var(--color-zs-border)      /* rgba(255,255,255,0.07) */
var(--color-zs-border-md)   /* rgba(255,255,255,0.12) */

/* Tipografía */
var(--font-display)         /* 'Syne' */
var(--font-body)            /* 'DM Sans' */

/* Layout */
var(--sidebar-w)            /* 248px */
```

---

## 2️⃣ Componentes que debes crear primero

Antes de las páginas, crea las carpetas y mueve los componentes:

```
components/
├── ui/
│   └── GlowingBox.tsx          ← componente nuevo
├── admin/
│   ├── sidebar.tsx             ← admin-sidebar.tsx
│   └── topbar.tsx              ← admin-topbar.tsx
└── tenant/
    ├── sidebar.tsx             ← tenant-sidebar.tsx
    └── topbar.tsx              ← tenant-topbar.tsx
```

---

## 3️⃣ Uso del GlowingBox

El `GlowingBox` reemplaza el anterior que no tenía estilos. Tiene 3 variantes:

```tsx
import { GlowingBox, KpiCard, Panel } from "@/components/ui/GlowingBox";

// Card glass genérica
<GlowingBox color="blue" intensity="md" topLine hoverable>
  <div className="p-5">Contenido</div>
</GlowingBox>

// KPI card con acento de color
<KpiCard
  label="Citas hoy"
  value="12"
  trend="+3 vs ayer"
  trendUp
  accent="blue"
  icon={<CalendarDays className="w-4 h-4" style={{ color: "var(--color-zs-blue-light)" }} />}
/>

// Panel con header estándar
<Panel
  title="Próximas citas"
  badge={<span className="zs-badge zs-badge-emerald">Live</span>}
  action={<Link href="/calendario">Ver todo →</Link>}
>
  {/* contenido */}
</Panel>
```

---

## 4️⃣ Clases CSS disponibles por categoría

### Cards y superficies
```html
<div class="zs-card">          <!-- glass card con hover -->
<div class="zs-panel">         <!-- panel sin hover -->
```

### Botones
```html
<button class="zs-btn">        <!-- botón azul principal -->
<button class="zs-btn-ghost">  <!-- botón outline -->
```

### Formularios
```html
<input class="zs-input">       <!-- input con focus ring azul -->
<label class="zs-label">       <!-- label uppercase pequeño -->
```

### Badges / Status
```html
<span class="zs-badge zs-badge-blue">     <!-- azul -->
<span class="zs-badge zs-badge-emerald">  <!-- verde -->
<span class="zs-badge zs-badge-amber">    <!-- amarillo -->
<span class="zs-badge zs-badge-rose">     <!-- rojo -->
<span class="zs-badge zs-badge-muted">    <!-- gris -->
```

### Navegación (sidebar)
```html
<a class="zs-nav-item active">  <!-- nav item activo -->
<a class="zs-nav-item">         <!-- nav item normal -->
<div class="zs-nav-icon">       <!-- ícono del nav -->
```

### Tablas
```html
<table class="zs-table">        <!-- tabla estilizada -->
```

### Texto
```html
<h1 class="zs-text-display">   <!-- Syne font -->
<span class="zs-text-gradient"><!-- gradiente azul→cyan -->
<span class="zs-text-gradient-warm"> <!-- violeta→azul→cyan -->
```

### Divisores
```html
<div class="zs-divider"><span>o</span></div>
```

### Animaciones
```html
<div class="zs-animate-up">         <!-- fade up al montar -->
<div class="zs-animate-in">         <!-- fade in al montar -->
<div class="zs-stagger">            <!-- aplica delays a hijos -->
  <div>hijo 1 — delay 50ms</div>
  <div>hijo 2 — delay 100ms</div>
</div>
<div class="zs-skeleton">           <!-- loading shimmer -->
<span class="zs-pulse-dot">         <!-- punto pulsante (live) -->
<div class="zs-spin">               <!-- spinner (Loader2) -->
```

### KPI accent lines
```html
<!-- Línea de color en el top del card -->
<div class="zs-kpi-accent blue">
<div class="zs-kpi-accent cyan">
<div class="zs-kpi-accent em">
<div class="zs-kpi-accent amber">
```

---

## 5️⃣ Consistencia entre páginas

El sistema usa exactamente las mismas variables en:
- `/login` — panel dividido, orbs de fondo
- `/registro` — card centrado con steps
- `/landing` — navbar glass, secciones con borders sutiles
- `/admin/*` — sidebar `zs-sidebar`, topbar `zs-topbar`
- `/(tenant)/*` — misma estructura, con nombre del tenant

---

## 6️⃣ Fuentes — asegurarte que cargan

En `app/layout.tsx` (root layout), verifica que tienes:

```tsx
import { Syne, DM_Sans } from "next/font/google";

const syne = Syne({
  subsets: ["latin"],
  variable: "--font-display",
  weight: ["400", "500", "600", "700", "800"],
});

const dmSans = DM_Sans({
  subsets: ["latin"],
  variable: "--font-body",
  style: ["normal", "italic"],
});

export default function RootLayout({ children }) {
  return (
    <html lang="es" className={`${syne.variable} ${dmSans.variable}`}>
      <body>{children}</body>
    </html>
  );
}
```

> **Nota:** El globals.css también importa desde Google Fonts como fallback. Con `next/font` es más rápido porque optimiza la carga.

---

## 7️⃣ Checklist de implementación

```
[ ] 1. Reemplazar globals.css
[ ] 2. Crear components/ui/GlowingBox.tsx
[ ] 3. Crear components/admin/sidebar.tsx + topbar.tsx
[ ] 4. Crear components/tenant/sidebar.tsx + topbar.tsx
[ ] 5. Actualizar app/admin/layout.tsx
[ ] 6. Actualizar app/(tenant)/layout.tsx
[ ] 7. Actualizar app/login/page.tsx
[ ] 8. Actualizar app/registro/page.tsx
[ ] 9. Actualizar app/landing/page.tsx
[ ] 10. Actualizar app/admin/page.tsx
[ ] 11. Actualizar app/(tenant)/page.tsx
[ ] 12. Verificar fuentes en root layout
[ ] 13. Borrar estilos viejos (vision-*, glassmorphism-* en components)
```

---

## 8️⃣ Posibles conflictos con código anterior

### Variables CSS antiguas → nuevas
```
--color-vision-blue   →  --color-zs-blue
--color-vision-dark   →  --color-zs-base
/* etc */
```

Si tienes componentes usando `--color-vision-*`, añade aliases temporales al globals.css:

```css
@layer base {
  :root {
    /* Compatibilidad temporal */
    --color-vision-blue: var(--color-zs-blue);
    --color-vision-dark: var(--color-zs-base);
  }
}
```

### GlowingBox anterior
Busca todos los usos del GlowingBox viejo y reemplázalos con el nuevo. El API es compatible — solo agrega `color` y `intensity` opcionales.

---

*Generado por Claude — ZonaSur Tech Design System v3*
