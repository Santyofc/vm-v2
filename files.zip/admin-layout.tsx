// app/admin/layout.tsx
import { AdminSidebar } from "@/components/admin/sidebar";
import { AdminTopbar } from "@/components/admin/topbar";

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen" style={{ background: "var(--color-zs-base)" }}>

      <AdminSidebar />

      <div className="flex flex-col flex-1" style={{ marginLeft: "var(--sidebar-w)" }}>
        <AdminTopbar />
        <main className="flex-1 overflow-y-auto relative z-10">
          <div className="max-w-[1400px] mx-auto">
            {children}
          </div>
        </main>
      </div>

    </div>
  );
}
