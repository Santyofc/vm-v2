// app/admin/page.tsx
export const dynamic = "force-dynamic";

import { getTenants } from "@/actions/admin";
import { getAdminHealthMetrics } from "@/actions/admin-metrics";
import { Plus, TrendingUp, Building2, CalendarCheck, DollarSign, AlertTriangle } from "lucide-react";

export default async function AdminDashboard() {
  const [tenants, health] = await Promise.allSettled([
    getTenants(),
    getAdminHealthMetrics(),
  ]);

  const tenantList  = tenants.status  === "fulfilled" ? tenants.value  : [];
  const healthData  = health.status   === "fulfilled" ? health.value   : null;

  const kpis = [
    {
      label: "Negocios activos",
      value: tenantList.length.toString(),
      icon:  Building2,
      trend: "+12% este mes",
      up:    true,
      accent: "blue",
      iconBg: "var(--color-zs-blue-dim)",
      iconColor: "var(--color-zs-blue-light)",
    },
    {
      label: "Citas procesadas",
      value: tenantList.reduce((a: number, t: any) => a + (t._count?.appointments ?? 0), 0).toLocaleString(),
      icon:  CalendarCheck,
      trend: "+8.4% este mes",
      up:    true,
      accent: "cyan",
      iconBg: "var(--color-zs-cyan-dim)",
      iconColor: "var(--color-zs-cyan)",
    },
    {
      label: "MRR estimado",
      value: "$4,200",
      icon:  DollarSign,
      trend: "+20% vs anterior",
      up:    true,
      accent: "em",
      iconBg: "var(--color-zs-em-dim)",
      iconColor: "var(--color-zs-emerald)",
    },
    {
      label: "Alertas sistema",
      value: healthData?.stripeErrors.toString() ?? "—",
      icon:  AlertTriangle,
      trend: `RAM ${healthData?.memUsage ?? 0}%`,
      up:    false,
      accent: "amber",
      iconBg: "var(--color-zs-amb-dim)",
      iconColor: "var(--color-zs-amber)",
    },
  ];

  const statusColor: Record<string, string> = {
    ACTIVE:   "var(--color-zs-emerald)",
    TRIALING: "var(--color-zs-amber)",
    PAST_DUE: "var(--color-zs-rose)",
    CANCELED: "var(--color-zs-text-muted)",
    null:     "var(--color-zs-text-muted)",
  };

  return (
    <div className="p-7 space-y-6 zs-stagger">

      {/* Header */}
      <header className="flex items-end justify-between zs-animate-up">
        <div>
          <p className="text-xs font-semibold tracking-widest uppercase mb-1"
            style={{ color: "var(--color-zs-text-muted)" }}>
            {new Date().toLocaleDateString("es-CR", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}
          </p>
          <h1 className="zs-text-display text-3xl font-black tracking-tight text-white">
            Consola Central <span className="zs-text-gradient">🚀</span>
          </h1>
        </div>
        <button className="zs-btn gap-2">
          <Plus className="w-4 h-4" /> Nuevo reporte
        </button>
      </header>

      {/* KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 zs-animate-up" style={{ animationDelay: "0.05s" }}>
        {kpis.map(({ label, value, icon: Icon, trend, up, accent, iconBg, iconColor }) => (
          <div key={label}
            className={`zs-card zs-kpi-accent ${accent} p-5 !rounded-2xl`}
            style={{ position: "relative" }}>
            <div className="flex items-start justify-between mb-4">
              <p className="text-xs font-bold tracking-widest uppercase" style={{ color: "var(--color-zs-text-muted)" }}>
                {label}
              </p>
              <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{ background: iconBg }}>
                <Icon className="w-4 h-4" style={{ color: iconColor }} />
              </div>
            </div>
            <p className="zs-text-display text-3xl font-black tracking-tight text-white mb-3">{value}</p>
            <span className="zs-badge text-[10px]"
              style={up
                ? { background: "var(--color-zs-em-dim)", color: "var(--color-zs-emerald)", border: "1px solid rgba(16,185,129,0.2)" }
                : { background: "var(--color-zs-amb-dim)", color: "var(--color-zs-amber)", border: "1px solid rgba(245,158,11,0.2)" }
              }>
              {up ? "↑" : "→"} {trend}
            </span>
          </div>
        ))}
      </div>

      {/* Middle row */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4 zs-animate-up" style={{ animationDelay: "0.1s" }}>

        {/* Revenue chart (mock) */}
        <div className="xl:col-span-2 zs-panel p-5 relative" style={{ position: "relative" }}>
          <div className="flex items-center justify-between mb-5">
            <div>
              <h3 className="zs-text-display font-bold text-base text-white">Ingresos mensuales</h3>
              <p className="text-xs mt-0.5" style={{ color: "var(--color-zs-text-muted)" }}>Últimos 7 meses</p>
            </div>
            <span className="zs-badge zs-badge-emerald">+20% YoY</span>
          </div>

          {/* Bar chart mockup */}
          <div className="flex items-end gap-2 h-40 px-2 pb-5 relative">
            {[
              { m: "Ago", h: 45 }, { m: "Sep", h: 55 }, { m: "Oct", h: 50 },
              { m: "Nov", h: 65 }, { m: "Dic", h: 60 }, { m: "Ene", h: 70 }, { m: "Feb", h: 88 },
            ].map(({ m, h }, i) => (
              <div key={m} className="flex-1 flex flex-col items-center gap-1 group">
                <div className="w-full rounded-t-lg transition-all group-hover:brightness-125 relative"
                  style={{
                    height: `${h}%`,
                    background: i === 6
                      ? `linear-gradient(180deg, var(--color-zs-blue) 0%, rgba(37,99,235,0.3) 100%)`
                      : "rgba(255,255,255,0.06)",
                    boxShadow: i === 6 ? "var(--shadow-blue)" : "none",
                  }} />
                <span className="text-[10px]" style={{ color: "var(--color-zs-text-muted)" }}>{m}</span>
              </div>
            ))}
          </div>
        </div>

        {/* System health */}
        <div className="zs-panel p-5 relative" style={{ position: "relative" }}>
          <div className="flex items-center justify-between mb-5">
            <h3 className="zs-text-display font-bold text-base text-white">Salud del sistema</h3>
            <span className="zs-badge zs-badge-emerald">
              <span className="zs-pulse-dot w-1.5 h-1.5 rounded-full bg-current" /> {healthData?.status ?? "HEALTHY"}
            </span>
          </div>

          <div className="space-y-4">
            {[
              { label: "CPU Load",     val: `${healthData?.cpuLoad ?? "—"}`,      pct: 34,  color: "var(--color-zs-blue)" },
              { label: "RAM Usage",    val: `${healthData?.memUsage ?? "—"}%`,     pct: healthData?.memUsage ?? 0, color: healthData?.memUsage && healthData.memUsage > 80 ? "var(--color-zs-rose)" : "var(--color-zs-emerald)" },
              { label: "DB Latency",   val: "72ms",                               pct: 18,  color: "var(--color-zs-amber)" },
              { label: "Uptime",       val: "99.9%",                              pct: 99,  color: "var(--color-zs-emerald)" },
            ].map(({ label, val, pct, color }) => (
              <div key={label}>
                <div className="flex justify-between mb-1.5">
                  <span className="text-xs font-medium" style={{ color: "var(--color-zs-text-muted)" }}>{label}</span>
                  <span className="zs-text-display text-xs font-bold" style={{ color }}>{val}</span>
                </div>
                <div className="zs-progress">
                  <div className="zs-progress-fill" style={{ width: `${pct}%`, background: color }} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Tenant table */}
      <div className="zs-panel overflow-hidden relative" style={{ position: "relative" }}>
        <div className="flex items-center justify-between p-5"
          style={{ borderBottom: "1px solid var(--color-zs-border)" }}>
          <h3 className="zs-text-display font-bold text-base text-white">Negocios registrados</h3>
          <button className="zs-btn-ghost text-xs py-1.5 px-3">Ver todos →</button>
        </div>

        <div className="overflow-x-auto">
          <table className="zs-table">
            <thead>
              <tr>
                <th>Negocio</th>
                <th>Estado</th>
                <th className="text-center">Usuarios</th>
                <th className="text-center">Citas</th>
                <th>Suscripción</th>
                <th>Creado</th>
              </tr>
            </thead>
            <tbody>
              {tenantList.slice(0, 8).map((t: any) => {
                const status = t.subscription?.status ?? null;
                const color  = statusColor[status] ?? statusColor["null"];
                return (
                  <tr key={t.id}>
                    <td>
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-lg flex items-center justify-center zs-text-display text-xs font-black flex-shrink-0"
                          style={{ background: "var(--color-zs-blue-dim)", color: "var(--color-zs-blue-light)" }}>
                          {t.name[0]}
                        </div>
                        <div>
                          <p className="font-semibold text-white">{t.name}</p>
                          <p className="text-xs" style={{ color: "var(--color-zs-text-muted)" }}>{t.slug}</p>
                        </div>
                      </div>
                    </td>
                    <td>
                      <div className="flex items-center gap-2">
                        <div className="w-1.5 h-1.5 rounded-full"
                          style={{ background: color, boxShadow: `0 0 6px ${color}` }} />
                        <span className="text-xs font-semibold" style={{ color }}>
                          {status ?? "Sin plan"}
                        </span>
                      </div>
                    </td>
                    <td className="text-center">
                      <span className="zs-text-display font-bold text-white">{t._count?.users ?? 0}</span>
                    </td>
                    <td className="text-center">
                      <span className="zs-text-display font-bold text-white">{t._count?.appointments ?? 0}</span>
                    </td>
                    <td>
                      {status
                        ? <span className="zs-badge" style={{ background: "var(--color-zs-blue-dim)", color: "var(--color-zs-blue-light)", border: "1px solid rgba(37,99,235,0.2)" }}>{status}</span>
                        : <span className="zs-badge zs-badge-muted">Sin suscripción</span>
                      }
                    </td>
                    <td style={{ color: "var(--color-zs-text-muted)" }} className="text-xs">
                      {new Date(t.createdAt).toLocaleDateString("es-CR", { month: "short", day: "numeric", year: "numeric" })}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {tenantList.length === 0 && (
            <div className="py-16 text-center" style={{ color: "var(--color-zs-text-muted)" }}>
              <Building2 className="w-8 h-8 mx-auto mb-3 opacity-40" />
              <p className="text-sm">No hay negocios registrados aún.</p>
            </div>
          )}
        </div>
      </div>

    </div>
  );
}
