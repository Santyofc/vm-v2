"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { signOut, useSession } from "next-auth/react";
import {
  LayoutDashboard, Building2, CreditCard, Activity,
  ShieldCheck, Settings, LogOut, ChevronLeft, ChevronRight,
} from "lucide-react";
import { cn } from "@/lib/utils";

const NAV = [
  {
    section: "Principal",
    items: [
      { label: "Dashboard",    href: "/admin",              icon: LayoutDashboard },
      { label: "Negocios",     href: "/admin/negocios",     icon: Building2, badge: "12" },
      { label: "Suscripciones",href: "/admin/suscripciones",icon: CreditCard },
    ]
  },
  {
    section: "Sistema",
    items: [
      { label: "Monitoreo",    href: "/admin/monitoring",   icon: Activity },
      { label: "Seguridad",    href: "/admin/seguridad",    icon: ShieldCheck },
      { label: "Configuración",href: "/admin/configuracion",icon: Settings },
    ]
  }
];

export function AdminSidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const pathname = usePathname();
  const { data: session } = useSession();

  const w = collapsed ? "w-[72px]" : "w-[248px]";

  return (
    <aside className={cn("zs-sidebar transition-all duration-300", w)}>

      {/* Brand */}
      <div className="flex items-center gap-3 px-4 py-5"
        style={{ borderBottom: "1px solid var(--color-zs-border)" }}>
        <div className="zs-brand-icon flex-shrink-0">
          <svg width="14" height="14" viewBox="0 0 20 20" fill="white">
            <path d="M10 2L2 7v6l8 5 8-5V7L10 2z"/>
          </svg>
        </div>
        {!collapsed && (
          <div className="overflow-hidden">
            <p className="zs-text-display font-black text-sm tracking-widest uppercase whitespace-nowrap">ZonaSur</p>
            <p className="text-[10px] font-semibold tracking-widest uppercase whitespace-nowrap"
              style={{ color: "var(--color-zs-blue-light)" }}>Admin Console</p>
          </div>
        )}
      </div>

      {/* Nav */}
      <nav className="flex-1 overflow-y-auto px-2 py-3">
        {NAV.map(({ section, items }) => (
          <div key={section} className="mb-2">
            {!collapsed && (
              <p className="px-3 py-2 text-[10px] font-black tracking-[0.14em] uppercase"
                style={{ color: "var(--color-zs-text-muted)" }}>
                {section}
              </p>
            )}
            {items.map(({ label, href, icon: Icon, badge }) => {
              const active = pathname === href || (href !== "/admin" && pathname.startsWith(href));
              return (
                <Link key={href} href={href}
                  className={cn("zs-nav-item", active && "active")}
                  title={collapsed ? label : undefined}>
                  <div className={cn("zs-nav-icon", active && "active")}>
                    <Icon className="w-[15px] h-[15px]" />
                  </div>
                  {!collapsed && (
                    <>
                      <span className="flex-1 truncate">{label}</span>
                      {badge && (
                        <span className="text-[10px] font-black px-1.5 py-0.5 rounded-md"
                          style={{ background: "var(--color-zs-rose-dim)", color: "var(--color-zs-rose)" }}>
                          {badge}
                        </span>
                      )}
                    </>
                  )}
                </Link>
              );
            })}
          </div>
        ))}
      </nav>

      {/* User */}
      <div className="px-2 py-3" style={{ borderTop: "1px solid var(--color-zs-border)" }}>

        {/* User card */}
        <div className={cn(
          "flex items-center gap-3 p-2.5 rounded-xl mb-2 transition-all",
          "cursor-default"
        )}
          style={{ background: "var(--color-zs-surface)", border: "1px solid var(--color-zs-border)" }}>
          <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0 zs-text-display font-black text-sm zs-glow-blue"
            style={{ background: "var(--color-zs-blue)" }}>
            {session?.user?.name?.[0] ?? "S"}
          </div>
          {!collapsed && (
            <div className="overflow-hidden flex-1 min-w-0">
              <p className="text-sm font-semibold text-white truncate">
                {session?.user?.name ?? "Superadmin"}
              </p>
              <p className="text-[10px] font-bold tracking-widest uppercase"
                style={{ color: "var(--color-zs-blue-light)" }}>
                {(session?.user as any)?.role ?? "SUPERADMIN"}
              </p>
            </div>
          )}
        </div>

        {/* Logout */}
        <button onClick={() => signOut()}
          className="zs-nav-item w-full"
          style={{ color: "var(--color-zs-rose)" }}>
          <div className="zs-nav-icon" style={{ background: "var(--color-zs-rose-dim)" }}>
            <LogOut className="w-[14px] h-[14px]" />
          </div>
          {!collapsed && <span>Cerrar sesión</span>}
        </button>
      </div>

      {/* Collapse toggle */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="absolute -right-3 top-14 w-6 h-6 rounded-full flex items-center justify-center z-10 transition-all hover:scale-110"
        style={{ background: "var(--color-zs-blue)", boxShadow: "var(--shadow-blue)" }}>
        {collapsed
          ? <ChevronRight className="w-3 h-3 text-white" />
          : <ChevronLeft className="w-3 h-3 text-white" />}
      </button>
    </aside>
  );
}
