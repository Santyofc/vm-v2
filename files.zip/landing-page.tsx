// app/landing/page.tsx
import Link from "next/link";
import { Suspense } from "react";
import {
  ArrowRight, Calendar, Clock, CreditCard, CheckCircle2,
  TrendingUp, ShieldCheck, Zap, Building2, ChevronRight
} from "lucide-react";
import { LiveDashboardPreview, DashboardSkeleton } from "@/components/landing/LiveDashboardPreview";
import { PricingButton } from "@/components/landing/PricingButton";

export default function LandingPage() {
  return (
    <div className="relative text-white overflow-x-hidden" style={{ background: "var(--color-zs-base)" }}>

      {/* ── Background orbs ── */}
      <div className="zs-orb" style={{ width: 800, height: 800, background: "radial-gradient(circle, rgba(37,99,235,0.18), transparent 70%)", top: -300, right: -200 }} />
      <div className="zs-orb" style={{ width: 600, height: 600, background: "radial-gradient(circle, rgba(6,182,212,0.08), transparent 70%)", top: "40%", left: -200 }} />
      <div className="zs-orb" style={{ width: 500, height: 500, background: "radial-gradient(circle, rgba(139,92,246,0.09), transparent 70%)", bottom: "10%", right: -100 }} />

      {/* ════════════ NAVBAR ════════════ */}
      <nav className="fixed top-0 w-full z-50"
        style={{ background: "rgba(6,8,15,0.75)", backdropFilter: "blur(20px)", borderBottom: "1px solid var(--color-zs-border)" }}>
        <div className="max-w-7xl mx-auto px-6 h-16 flex items-center justify-between">

          <div className="flex items-center gap-3">
            <div className="zs-brand-icon">
              <svg width="14" height="14" viewBox="0 0 20 20" fill="white"><path d="M10 2L2 7v6l8 5 8-5V7L10 2z"/></svg>
            </div>
            <span className="zs-text-display font-black text-sm tracking-widest uppercase">ZonaSur Tech</span>
          </div>

          <div className="hidden md:flex gap-8">
            {["#caracteristicas", "#beneficios", "#precios"].map((href, i) => (
              <a key={href} href={href}
                className="text-sm font-medium transition-colors"
                style={{ color: "var(--color-zs-text-muted)" }}
                onMouseEnter={e => (e.currentTarget.style.color = "white")}
                onMouseLeave={e => (e.currentTarget.style.color = "var(--color-zs-text-muted)")}>
                {["Características", "Beneficios", "Precios"][i]}
              </a>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <Link href="/login"
              className="text-sm font-medium hidden sm:block transition-colors"
              style={{ color: "var(--color-zs-text-muted)" }}>
              Iniciar Sesión
            </Link>
            <Link href="/registro" className="zs-btn text-sm py-2 px-4">
              Empezar Gratis <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          </div>
        </div>
      </nav>

      {/* ════════════ HERO ════════════ */}
      <section className="relative pt-36 pb-24 px-6">
        <div className="max-w-5xl mx-auto text-center">

          {/* Eyebrow */}
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-8 text-xs font-semibold"
            style={{ background: "rgba(37,99,235,0.1)", border: "1px solid rgba(37,99,235,0.2)" }}>
            <span className="w-1.5 h-1.5 rounded-full zs-pulse-dot"
              style={{ background: "var(--color-zs-cyan)" }} />
            <span style={{ color: "var(--color-zs-cyan)" }}>La plataforma definitiva para tu negocio</span>
          </div>

          {/* Heading */}
          <h1 className="zs-text-display text-5xl md:text-7xl font-black leading-[1.02] tracking-tight text-white mb-6 zs-animate-up">
            Ahorra horas de gestión<br />
            <span className="zs-text-gradient-warm">y automatiza tus citas.</span>
          </h1>

          <p className="text-lg md:text-xl max-w-2xl mx-auto mb-10 leading-relaxed zs-animate-up"
            style={{ color: "var(--color-zs-text-muted)", animationDelay: "0.1s" }}>
            El sistema todo-en-uno para clínicas, salones y consultorios.
            Elimina el papeleo, fideliza clientes y enfócate en lo que mejor sabes hacer.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-20 zs-animate-up"
            style={{ animationDelay: "0.15s" }}>
            <Link href="/registro" className="zs-btn text-base py-3.5 px-8 gap-2">
              Crear mi cuenta gratis <ArrowRight className="w-4 h-4" />
            </Link>
            <Link href="/login" className="zs-btn-ghost text-base py-3.5 px-8">
              Acceso Clientes
            </Link>
          </div>

          {/* Dashboard preview */}
          <div className="relative rounded-t-3xl overflow-hidden zs-animate-up"
            style={{
              border: "1px solid var(--color-zs-border)",
              borderBottom: "none",
              background: "rgba(10,13,24,0.7)",
              backdropFilter: "blur(20px)",
              animationDelay: "0.2s",
              boxShadow: "0 -20px 80px rgba(37,99,235,0.12)",
            }}>

            {/* Fade out bottom */}
            <div className="absolute inset-x-0 bottom-0 h-32 z-20 pointer-events-none"
              style={{ background: "linear-gradient(to top, var(--color-zs-base), transparent)" }} />

            {/* Browser bar */}
            <div className="flex items-center gap-2 px-4 h-10"
              style={{ borderBottom: "1px solid var(--color-zs-border)", background: "rgba(0,0,0,0.3)" }}>
              {["#ef4444","#f59e0b","#10b981"].map((c) => (
                <div key={c} className="w-3 h-3 rounded-full" style={{ background: c, opacity: 0.7 }} />
              ))}
              <div className="mx-auto px-16 py-1 rounded-lg text-xs hidden sm:block"
                style={{ background: "rgba(0,0,0,0.4)", color: "var(--color-zs-text-muted)" }}>
                cita.zonasurtech.online
              </div>
            </div>

            {/* Dashboard content */}
            <div className="p-6 md:p-8">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h3 className="zs-text-display text-xl font-black text-white">Panel de Control</h3>
                  <p className="text-sm" style={{ color: "var(--color-zs-text-muted)" }}>Barbería Elite — Hoy</p>
                </div>
                <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold"
                  style={{ background: "var(--color-zs-blue-dim)", color: "var(--color-zs-blue-light)", border: "1px solid rgba(37,99,235,0.2)" }}>
                  <span className="w-1.5 h-1.5 rounded-full zs-pulse-dot bg-current" />
                  En vivo
                </div>
              </div>

              <div className="grid grid-cols-3 gap-4 mb-6">
                {[
                  { l: "Citas Hoy",          v: "12",   up: true,  c: "var(--color-zs-blue-light)" },
                  { l: "Ingresos Est.",       v: "$450", up: true,  c: "var(--color-zs-emerald)" },
                  { l: "Tasa Asistencia",     v: "98%",  up: false, c: "var(--color-zs-cyan)" },
                ].map(({ l, v, up, c }) => (
                  <div key={l} className="zs-card p-4 !rounded-xl" style={{ position: "relative" }}>
                    <p className="text-xs mb-2" style={{ color: "var(--color-zs-text-muted)" }}>{l}</p>
                    <p className="zs-text-display text-2xl font-black" style={{ color: c }}>{v}</p>
                    <p className="text-xs mt-1" style={{ color: "var(--color-zs-emerald)" }}>
                      {up ? "↑ +20% vs ayer" : "Promedio óptimo"}
                    </p>
                  </div>
                ))}
              </div>

              {/* Live appointments */}
              <div className="zs-card overflow-hidden !rounded-xl" style={{ position: "relative" }}>
                <div className="px-4 py-3" style={{ borderBottom: "1px solid var(--color-zs-border)" }}>
                  <p className="text-xs font-bold tracking-widest uppercase" style={{ color: "var(--color-zs-text-muted)" }}>
                    Próximas Citas
                  </p>
                </div>
                <Suspense fallback={<DashboardSkeleton />}>
                  <LiveDashboardPreview />
                </Suspense>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ════════════ FEATURES ════════════ */}
      <section id="caracteristicas" className="py-24 px-6"
        style={{ borderTop: "1px solid var(--color-zs-border)" }}>
        <div className="max-w-7xl mx-auto">

          <div className="text-center mb-16">
            <div className="zs-eyebrow justify-center mb-4" style={{ color: "var(--color-zs-blue-light)" }}>
              <span className="w-6 h-px bg-current" /> Características <span className="w-6 h-px bg-current" />
            </div>
            <h2 className="zs-text-display text-4xl md:text-5xl font-black tracking-tight text-white mb-5">
              Diseñado para el mundo real
            </h2>
            <p className="text-lg max-w-2xl mx-auto" style={{ color: "var(--color-zs-text-muted)" }}>
              No solo un calendario. Un motor de operaciones completo que trabaja 24/7 para tu negocio.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                icon: Clock,
                iconBg: "var(--color-zs-blue-dim)",
                iconColor: "var(--color-zs-blue-light)",
                title: "Reservas Autónomas 24/7",
                desc: "Tu negocio nunca duerme. Los clientes reservan en cualquier momento desde un portal optimizado para móviles, sincronizado al instante con tu disponibilidad real.",
              },
              {
                icon: Calendar,
                iconBg: "var(--color-zs-em-dim)",
                iconColor: "var(--color-zs-emerald)",
                title: "Gestión Anti-Ausencias",
                desc: "El 20% de las citas se pierden por olvido. Nuestro sistema dispara recordatorios inteligentes por Email y SMS, reduciendo las plantadas y asegurando la ocupación.",
              },
              {
                icon: CreditCard,
                iconBg: "var(--color-zs-cyan-dim)",
                iconColor: "var(--color-zs-cyan)",
                title: "Métricas Financieras en Vivo",
                desc: "Deja de adivinar cuánto ganaste. Visualiza ingresos del día, servicios más rentables y tasa de asistencia. Decisiones basadas en datos, no en intuición.",
              },
            ].map(({ icon: Icon, iconBg, iconColor, title, desc }) => (
              <div key={title}
                className="zs-card p-7 !rounded-3xl group"
                style={{ position: "relative" }}>
                <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-6 transition-transform group-hover:scale-110"
                  style={{ background: iconBg }}>
                  <Icon className="w-6 h-6" style={{ color: iconColor }} />
                </div>
                <h3 className="zs-text-display text-xl font-bold text-white mb-3">{title}</h3>
                <p className="text-sm leading-relaxed" style={{ color: "var(--color-zs-text-muted)" }}>{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ════════════ BENEFITS ════════════ */}
      <section id="beneficios" className="py-24 px-6"
        style={{ borderTop: "1px solid var(--color-zs-border)" }}>
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-16 items-center">

            <div>
              <div className="zs-eyebrow mb-5" style={{ color: "var(--color-zs-emerald)" }}>
                <span className="w-6 h-px bg-current" /> Impacto real
              </div>
              <h2 className="zs-text-display text-4xl md:text-5xl font-black tracking-tight text-white mb-6">
                El impacto de digitalizar<br />tu gestión.
              </h2>
              <p className="text-lg leading-relaxed mb-10" style={{ color: "var(--color-zs-text-muted)" }}>
                Nuestros clientes no solo ahorran tiempo — transforman la manera en que operan y perciben su propio negocio.
              </p>

              <div className="space-y-5">
                {[
                  { color: "var(--color-zs-emerald)", title: "Aumento de Ingresos (ROI)", desc: "Los negocios experimentan un incremento promedio del 30% en facturación durante el primer trimestre al minimizar huecos y no-shows." },
                  { color: "var(--color-zs-blue-light)", title: "Control Absoluto del Tiempo", desc: "Recupera hasta 15 horas semanales que antes perdías coordinando mensajes y resolviendo conflictos de calendario." },
                  { color: "var(--color-zs-violet)", title: "Experiencia Premium para Clientes", desc: "Proyecta una imagen corporativa, seria y confiable desde el primer clic que hace tu cliente para reservar." },
                ].map(({ color, title, desc }) => (
                  <div key={title} className="flex items-start gap-4">
                    <div className="w-8 h-8 rounded-xl flex items-center justify-center flex-shrink-0 mt-0.5"
                      style={{ background: `${color}1a`, border: `1px solid ${color}30` }}>
                      <CheckCircle2 className="w-4 h-4" style={{ color }} />
                    </div>
                    <div>
                      <h4 className="font-bold text-white mb-1">{title}</h4>
                      <p className="text-sm leading-relaxed" style={{ color: "var(--color-zs-text-muted)" }}>{desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Metrics card */}
            <div className="zs-card p-8 !rounded-3xl relative overflow-hidden" style={{ position: "relative" }}>
              <div className="absolute top-0 right-0 w-48 h-48 -mr-12 -mt-12 rounded-full"
                style={{ background: "radial-gradient(circle, rgba(37,99,235,0.15), transparent 70%)", filter: "blur(30px)" }} />

              <div className="relative z-10">
                <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-lg mb-8 text-xs font-bold"
                  style={{ background: "var(--color-zs-blue-dim)", color: "var(--color-zs-blue-light)", border: "1px solid rgba(37,99,235,0.2)" }}>
                  <TrendingUp className="w-3.5 h-3.5" /> Métrica de Impacto
                </div>

                <div className="space-y-6 mb-8">
                  <div>
                    <div className="zs-text-display text-5xl font-black text-white mb-1">+30%</div>
                    <p style={{ color: "var(--color-zs-text-muted)" }} className="text-sm">Crecimiento promedio de ingresos mensuales</p>
                  </div>
                  <div className="h-px" style={{ background: "var(--color-zs-border)" }} />
                  <div>
                    <div className="zs-text-display text-5xl font-black text-white mb-1">-15h</div>
                    <p style={{ color: "var(--color-zs-text-muted)" }} className="text-sm">Ahorradas en tareas administrativas semanales</p>
                  </div>
                </div>

                <div className="flex items-center gap-4 p-4 rounded-2xl"
                  style={{ background: "var(--color-zs-surface)", border: "1px solid var(--color-zs-border)" }}>
                  <div className="w-11 h-11 rounded-xl flex items-center justify-center"
                    style={{ background: "var(--color-zs-em-dim)" }}>
                    <ShieldCheck className="w-5 h-5" style={{ color: "var(--color-zs-emerald)" }} />
                  </div>
                  <div>
                    <p className="font-bold text-sm text-white">Sistema Verificado y Protegido</p>
                    <p className="text-xs mt-0.5" style={{ color: "var(--color-zs-text-muted)" }}>
                      Copias de seguridad cada 24h · TLS encriptado
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ════════════ PRICING ════════════ */}
      <section id="precios" className="py-24 px-6"
        style={{ borderTop: "1px solid var(--color-zs-border)" }}>
        <div className="max-w-7xl mx-auto">

          <div className="text-center mb-16">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full mb-5 text-xs font-semibold"
              style={{ background: "var(--color-zs-blue-dim)", color: "var(--color-zs-blue-light)", border: "1px solid rgba(37,99,235,0.2)" }}>
              Sin contratos forzosos · Cancela cuando quieras
            </div>
            <h2 className="zs-text-display text-4xl md:text-5xl font-black tracking-tight text-white mb-5">
              Un plan para cada etapa
            </h2>
            <p className="text-lg max-w-xl mx-auto" style={{ color: "var(--color-zs-text-muted)" }}>
              Comienza sin tarjeta y escala conforme tu negocio crece.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">

            {/* Free */}
            <div className="zs-card p-7 !rounded-3xl flex flex-col" style={{ position: "relative" }}>
              <div className="mb-7">
                <h3 className="zs-text-display text-lg font-bold text-white mb-2">Prueba Gratis</h3>
                <div className="flex items-baseline gap-2">
                  <span className="zs-text-display text-4xl font-black text-white">$0</span>
                  <span style={{ color: "var(--color-zs-text-muted)" }}>/ 14 días</span>
                </div>
                <p className="text-sm mt-3" style={{ color: "var(--color-zs-text-muted)" }}>Explora sin compromisos.</p>
              </div>
              <ul className="space-y-3 mb-7 flex-1">
                {["Acceso Total Inmediato", "Agenda interactiva", "Sin tarjeta de crédito"].map((f) => (
                  <li key={f} className="flex gap-3 text-sm" style={{ color: "var(--color-zs-text-muted)" }}>
                    <CheckCircle2 className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: "var(--color-zs-text-muted)" }} />
                    {f}
                  </li>
                ))}
              </ul>
              <Link href="/registro" className="zs-btn-ghost w-full justify-center py-3">
                Crear Cuenta Gratis
              </Link>
            </div>

            {/* Esencial */}
            <div className="zs-card p-7 !rounded-3xl flex flex-col" style={{ position: "relative" }}>
              <div className="mb-7">
                <h3 className="zs-text-display text-lg font-bold text-white mb-2">Esencial</h3>
                <div className="flex items-baseline gap-2">
                  <span className="zs-text-display text-4xl font-black text-white">$29</span>
                  <span style={{ color: "var(--color-zs-text-muted)" }}>/ mes</span>
                </div>
                <p className="text-sm mt-3" style={{ color: "var(--color-zs-text-muted)" }}>Para profesionales y consultorios pequeños.</p>
              </div>
              <ul className="space-y-3 mb-7 flex-1">
                {["Hasta 100 citas/mes", "Recordatorios (Email)", "Dashboard financiero", "1 cuenta de staff"].map((f) => (
                  <li key={f} className="flex gap-3 text-sm text-white">
                    <CheckCircle2 className="w-4 h-4 flex-shrink-0 mt-0.5" style={{ color: "var(--color-zs-emerald)" }} />
                    {f}
                  </li>
                ))}
              </ul>
              <PricingButton priceId="price_esencial_id" planName="Esencial"
                className="w-full py-3 rounded-xl text-sm font-bold text-white justify-center"
                style={{ background: "var(--color-zs-surface)", border: "1px solid var(--color-zs-border-md)" }} />
            </div>

            {/* Elite */}
            <div className="relative flex flex-col p-7 rounded-3xl overflow-hidden"
              style={{
                background: "rgba(10,13,30,0.8)",
                border: "1px solid rgba(37,99,235,0.4)",
                backdropFilter: "blur(28px)",
                boxShadow: "0 0 60px rgba(37,99,235,0.12)",
              }}>
              {/* Top accent */}
              <div className="absolute top-0 left-0 right-0 h-[2px]"
                style={{ background: "linear-gradient(90deg, var(--color-zs-emerald), var(--color-zs-blue), var(--color-zs-violet))" }} />

              <div className="flex items-start justify-between mb-7">
                <div>
                  <h3 className="zs-text-display text-lg font-bold text-white mb-2">Elite Pro</h3>
                  <div className="flex items-baseline gap-2">
                    <span className="zs-text-display text-4xl font-black text-white">$79</span>
                    <span style={{ color: "var(--color-zs-text-muted)" }}>/ mes</span>
                  </div>
                  <p className="text-sm mt-3" style={{ color: "var(--color-zs-text-muted)" }}>Para clínicas y salones de gran volumen.</p>
                </div>
                <span className="zs-text-display text-xs font-black px-2.5 py-1 rounded-full bg-white text-black">
                  Recomendado
                </span>
              </div>

              <ul className="space-y-3 mb-7 flex-1">
                {[
                  "Citas ilimitadas",
                  "Cuentas de staff ilimitadas",
                  "Recordatorios Email + SMS",
                  "Reportes y exportación",
                  "Soporte VIP 24/7",
                ].map((f) => (
                  <li key={f} className="flex gap-3 text-sm text-white">
                    <CheckCircle2 className="w-4 h-4 flex-shrink-0 mt-0.5"
                      style={{ color: "var(--color-zs-blue-light)" }} />
                    {f}
                  </li>
                ))}
              </ul>

              <PricingButton priceId="price_elite_id" planName="Elite Pro" isPopular={true}
                className="w-full py-3 rounded-xl text-sm font-bold text-black justify-center bg-white hover:bg-zinc-100 transition-colors" />
            </div>
          </div>
        </div>
      </section>

      {/* ════════════ CTA ════════════ */}
      <section id="contacto" className="py-24 px-6"
        style={{ borderTop: "1px solid var(--color-zs-border)" }}>
        <div className="max-w-3xl mx-auto text-center">
          <div className="zs-eyebrow justify-center mb-5" style={{ color: "var(--color-zs-cyan)" }}>
            <span className="w-8 h-px bg-current" /> Empieza hoy <span className="w-8 h-px bg-current" />
          </div>
          <h2 className="zs-text-display text-4xl md:text-5xl font-black tracking-tight text-white mb-5">
            ¿Listo para transformar<br />tu negocio?
          </h2>
          <p className="text-lg mb-10" style={{ color: "var(--color-zs-text-muted)" }}>
            Agenda una consultoría personalizada o activa tu demo hoy mismo.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="https://wa.me/50687623229?text=Hola%20Zona%20Sur%20Tech"
              className="zs-btn py-4 px-8 text-base gap-2"
              style={{ background: "#25D366", boxShadow: "0 4px 20px rgba(37,211,102,0.3)" }}>
              💬 WhatsApp Directo
            </a>
            <Link href="/registro" className="zs-btn-ghost py-4 px-8 text-base">
              Registrarme Gratis <ChevronRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* ════════════ FOOTER ════════════ */}
      <footer style={{ borderTop: "1px solid var(--color-zs-border)", background: "rgba(0,0,0,0.3)" }}
        className="py-12 px-6">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="zs-brand-icon">
              <svg width="12" height="12" viewBox="0 0 20 20" fill="white"><path d="M10 2L2 7v6l8 5 8-5V7L10 2z"/></svg>
            </div>
            <span className="zs-text-display font-black text-sm tracking-widest uppercase"
              style={{ color: "var(--color-zs-text-muted)" }}>
              ZonaSur Tech
            </span>
          </div>
          <p className="text-sm" style={{ color: "var(--color-zs-text-muted)" }}>
            © {new Date().getFullYear()} ZonaSur Tech. Todos los derechos reservados.
          </p>
          <div className="flex gap-6">
            {[["Términos", "/terminos"], ["Privacidad", "/privacidad"]].map(([l, h]) => (
              <Link key={l} href={h} className="text-sm transition-colors"
                style={{ color: "var(--color-zs-text-muted)" }}>
                {l}
              </Link>
            ))}
          </div>
        </div>
      </footer>

    </div>
  );
}
