"use client";

import { useState } from "react";
import { signIn } from "next-auth/react";
import Link from "next/link";
import { Loader2, User, Mail, Lock, Building2, Eye, EyeOff, CheckCircle2 } from "lucide-react";

const PLANS = [
  { id: "free",     emoji: "🆓", name: "Gratis",   price: "14 días" },
  { id: "esencial", emoji: "⚡", name: "Esencial", price: "$29/mes"  },
  { id: "elite",    emoji: "👑", name: "Elite",    price: "$79/mes"  },
];

export default function RegisterPage() {
  const [plan, setPlan]       = useState("free");
  const [showPass, setShowPass] = useState(false);
  const [loading, setLoading]  = useState(false);
  const [error, setError]      = useState("");

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoading(true);
    setError("");
    const fd = new FormData(e.currentTarget);

    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name:         `${fd.get("firstName")} ${fd.get("lastName")}`.trim(),
          email:        (fd.get("email") as string).trim().toLowerCase(),
          password:     fd.get("password"),
          businessName: fd.get("businessName"),
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Error al registrarse.");

      await signIn("credentials", {
        email:    (fd.get("email") as string).trim().toLowerCase(),
        password: fd.get("password"),
        redirect: false,
      });
      window.location.href = "/";
    } catch (err: any) {
      setError(err.message);
      setLoading(false);
    }
  };

  return (
    <div className="relative min-h-screen flex items-center justify-center py-12 px-4"
      style={{ background: "var(--color-zs-base)" }}>

      {/* Orbs */}
      <div className="zs-orb" style={{ width: 700, height: 700, background: "radial-gradient(circle, rgba(37,99,235,0.18), transparent 70%)", top: -300, left: "50%", transform: "translateX(-50%)" }} />
      <div className="zs-orb" style={{ width: 400, height: 400, background: "radial-gradient(circle, rgba(16,185,129,0.09), transparent 70%)", bottom: -100, right: -80 }} />

      <div className="relative z-10 w-full max-w-[520px]">

        {/* Header */}
        <div className="text-center mb-8 zs-animate-up">
          <div className="inline-flex items-center gap-3 mb-6">
            <div className="zs-brand-icon">
              <svg width="14" height="14" viewBox="0 0 20 20" fill="white"><path d="M10 2L2 7v6l8 5 8-5V7L10 2z"/></svg>
            </div>
            <span className="zs-text-display font-black text-sm tracking-widest uppercase">ZonaSur Tech</span>
          </div>
          <div className="zs-eyebrow justify-center mb-3"
            style={{ color: "var(--color-zs-emerald)" }}>
            <span className="w-4 h-px bg-current" /> nuevo negocio <span className="w-4 h-px bg-current" />
          </div>
          <h1 className="zs-text-display text-4xl font-black tracking-tight text-white mb-2">
            Empieza en 2 minutos
          </h1>
          <p className="text-sm" style={{ color: "var(--color-zs-text-muted)" }}>
            Sin tarjeta de crédito · 14 días gratis · Cancela cuando quieras
          </p>
        </div>

        {/* Card */}
        <div className="zs-card p-8 zs-animate-up" style={{ animationDelay: "0.1s" }}>

          {/* Top accent line */}
          <div className="absolute top-0 left-0 right-0 h-[2px] rounded-t-xl"
            style={{ background: "linear-gradient(90deg, transparent, var(--color-zs-blue), var(--color-zs-cyan), transparent)" }} />

          {/* OAuth */}
          <div className="grid grid-cols-2 gap-3 mb-5">
            <button className="zs-btn-ghost text-sm py-2.5 justify-center gap-2">
              <svg viewBox="0 0 24 24" className="w-4 h-4 flex-shrink-0">
                <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
                <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
                <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
                <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
              </svg>
              Google
            </button>
            <button
              onClick={() => signIn("github", { callbackUrl: "/" })}
              className="zs-btn-ghost text-sm py-2.5 justify-center gap-2">
              <svg viewBox="0 0 24 24" fill="currentColor" className="w-4 h-4 flex-shrink-0">
                <path d="M12 0C5.37 0 0 5.37 0 12c0 5.31 3.435 9.795 8.205 11.385.6.105.825-.255.825-.57 0-.285-.015-1.23-.015-2.235-3.015.555-3.795-.735-4.035-1.41-.135-.345-.72-1.41-1.23-1.695-.42-.225-1.02-.78-.015-.795.945-.015 1.62.87 1.845 1.23 1.08 1.815 2.805 1.305 3.495.99.105-.78.42-1.305.765-1.605-2.67-.3-5.46-1.335-5.46-5.925 0-1.305.465-2.385 1.23-3.225-.12-.3-.54-1.53.12-3.18 0 0 1.005-.315 3.3 1.23.96-.27 1.98-.405 3-.405s2.04.135 3 .405c2.295-1.56 3.3-1.23 3.3-1.23.66 1.65.24 2.88.12 3.18.765.84 1.23 1.905 1.23 3.225 0 4.605-2.805 5.625-5.475 5.925.435.375.81 1.095.81 2.22 0 1.605-.015 2.895-.015 3.3 0 .315.225.69.825.57A12.02 12.02 0 0 0 24 12c0-6.63-5.37-12-12-12z"/>
              </svg>
              GitHub
            </button>
          </div>

          <div className="zs-divider mb-5">
            <span>o completa el formulario</span>
          </div>

          {error && (
            <div className="flex items-center gap-2 p-3 mb-4 rounded-xl text-sm"
              style={{ background: "var(--color-zs-rose-dim)", border: "1px solid rgba(244,63,94,0.2)", color: "#fca5a5" }}>
              ⚠ {error}
            </div>
          )}

          <form onSubmit={handleSubmit} className="flex flex-col gap-4">

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="zs-label">Nombre</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5" style={{ color: "var(--color-zs-text-muted)" }} />
                  <input name="firstName" type="text" required placeholder="Tu nombre" className="zs-input" />
                </div>
              </div>
              <div>
                <label className="zs-label">Apellido</label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5" style={{ color: "var(--color-zs-text-muted)" }} />
                  <input name="lastName" type="text" required placeholder="Tu apellido" className="zs-input" />
                </div>
              </div>
            </div>

            <div>
              <label className="zs-label">Nombre del negocio</label>
              <div className="relative">
                <Building2 className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5" style={{ color: "var(--color-zs-text-muted)" }} />
                <input name="businessName" type="text" required placeholder="Ej: Barbería Elite, Spa Central..." className="zs-input" />
              </div>
            </div>

            <div>
              <label className="zs-label">Correo electrónico</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5" style={{ color: "var(--color-zs-text-muted)" }} />
                <input name="email" type="email" required placeholder="tu@empresa.com" className="zs-input" autoComplete="email" />
              </div>
            </div>

            <div>
              <label className="zs-label">Contraseña</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-3.5 h-3.5" style={{ color: "var(--color-zs-text-muted)" }} />
                <input name="password" type={showPass ? "text" : "password"} required minLength={8}
                  placeholder="Mínimo 8 caracteres" className="zs-input pr-10" />
                <button type="button" onClick={() => setShowPass(!showPass)}
                  className="absolute right-3 top-1/2 -translate-y-1/2"
                  style={{ color: "var(--color-zs-text-muted)" }}>
                  {showPass ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Plan selector */}
            <div>
              <label className="zs-label">Plan inicial</label>
              <div className="grid grid-cols-3 gap-2">
                {PLANS.map((p) => (
                  <button key={p.id} type="button" onClick={() => setPlan(p.id)}
                    className="flex flex-col items-center py-3 px-2 rounded-xl border text-center transition-all"
                    style={{
                      background: plan === p.id ? "var(--color-zs-blue-dim)" : "var(--color-zs-surface)",
                      borderColor: plan === p.id ? "rgba(37,99,235,0.4)" : "var(--color-zs-border)",
                    }}>
                    <span className="text-xl mb-1">{p.emoji}</span>
                    <span className="zs-text-display text-xs font-bold text-white">{p.name}</span>
                    <span className="text-xs" style={{ color: "var(--color-zs-text-muted)" }}>{p.price}</span>
                  </button>
                ))}
              </div>
            </div>

            {/* Terms */}
            <label className="flex items-start gap-3 p-3 rounded-xl cursor-pointer"
              style={{ background: "var(--color-zs-surface)", border: "1px solid var(--color-zs-border)" }}>
              <input type="checkbox" required className="mt-0.5 w-4 h-4 accent-blue-600 flex-shrink-0" />
              <span className="text-xs leading-relaxed" style={{ color: "var(--color-zs-text-muted)" }}>
                Al registrarte, aceptas nuestros{" "}
                <Link href="/terminos" className="underline" style={{ color: "var(--color-zs-blue-light)" }}>Términos</Link>{" "}
                y{" "}
                <Link href="/privacidad" className="underline" style={{ color: "var(--color-zs-blue-light)" }}>Privacidad</Link>.
                Tu información está protegida con TLS.
              </span>
            </label>

            <button type="submit" disabled={loading} className="zs-btn w-full py-3 text-base mt-1">
              {loading ? (
                <><Loader2 className="w-4 h-4 zs-spin" /> Creando tu negocio...</>
              ) : (
                <><span>🚀</span> Crear mi negocio gratis</>
              )}
            </button>
          </form>

          <p className="text-center text-sm mt-5" style={{ color: "var(--color-zs-text-muted)" }}>
            ¿Ya tienes cuenta?{" "}
            <Link href="/login" className="font-bold" style={{ color: "var(--color-zs-cyan)" }}>
              Inicia sesión
            </Link>
          </p>
        </div>

        {/* Trust badges */}
        <div className="flex justify-center gap-6 mt-6">
          {["🔒 SSL encriptado", "🛡️ GDPR", "⚡ Sin contrato"].map((b) => (
            <span key={b} className="text-xs" style={{ color: "var(--color-zs-text-muted)" }}>{b}</span>
          ))}
        </div>
      </div>
    </div>
  );
}
