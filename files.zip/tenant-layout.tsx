// app/(tenant)/layout.tsx
import { TenantSidebar } from "@/components/tenant/sidebar";
import { TenantTopbar }  from "@/components/tenant/topbar";

export default function TenantLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div
      className="flex min-h-screen"
      style={{ background: "var(--color-zs-base)" }}
    >
      <TenantSidebar />

      <div
        className="flex flex-col flex-1"
        style={{ marginLeft: "var(--sidebar-w)" }}
      >
        <TenantTopbar />
        <main className="flex-1 overflow-y-auto relative z-10">
          <div className="max-w-[1200px] mx-auto">{children}</div>
        </main>
      </div>
    </div>
  );
}
