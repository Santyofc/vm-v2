// app/tenant/page.tsx
export const dynamic = "force-dynamic";

import { getDashboardMetrics, getUpcomingAppointments } from "@/actions/tenant";
import { auth } from "@/auth";
import Link from "next/link";
import { formatTime, formatCurrency } from "@/lib/utils";
import {
  CalendarDays, DollarSign, CheckCircle, Star,
  ArrowRight, Clock, TrendingUp, Zap
} from "lucide-react";

const STATUS_CONFIG: Record<string, { label: string; color: string; bg: string; border: string }> = {
  PENDING:   { label: "Pendiente",  color: "var(--color-zs-amber)",   bg: "var(--color-zs-amb-dim)",  border: "rgba(245,158,11,0.2)"  },
  CONFIRMED: { label: "Confirmado", color: "var(--color-zs-emerald)", bg: "var(--color-zs-em-dim)",   border: "rgba(16,185,129,0.2)"  },
  CANCELLED: { label: "Cancelado",  color: "var(--color-zs-rose)",    bg: "var(--color-zs-rose-dim)", border: "rgba(244,63,94,0.2)"   },
  COMPLETED: { label: "Completado", color: "var(--color-zs-text-md)", bg: "var(--color-zs-surface-hi)",border:"var(--color-zs-border)"},
};

export default async function TenantDashboard() {
  const session   = await auth();
  const tenantId  = (session?.user as any)?.tenantId;

  if (!tenantId) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] p-8 text-center">
        <div className="w-20 h-20 rounded-2xl flex items-center justify-center text-4xl mb-6 zs-card">👑</div>
        <h1 className="zs-text-display text-3xl font-black tracking-tight text-white mb-3">Modo SuperAdmin</h1>
        <p className="text-base max-w-md mb-8" style={{ color: "var(--color-zs-text-muted)" }}>
          Navega con la cuenta maestra. Selecciona un negocio o accede al panel global.
        </p>
        <Link href="https://admin.zonasurtech.online" className="zs-btn gap-2 px-6 py-3 text-base">
          <Zap className="w-4 h-4" /> Ir al Panel Admin
        </Link>
      </div>
    );
  }

  const [metricsResult, appointmentsResult] = await Promise.allSettled([
    getDashboardMetrics(),
    getUpcomingAppointments(),
  ]);

  const metrics      = metricsResult.status      === "fulfilled" ? metricsResult.value      : null;
  const appointments = appointmentsResult.status === "fulfilled" ? appointmentsResult.value : [];

  const kpis = [
    {
      label: "Citas hoy",
      value: metrics?.todayAppointments ?? 0,
      icon:  CalendarDays,
      trend: "+3 vs ayer",
      up:    true,
      accent: "blue",
      iconColor: "var(--color-zs-blue-light)",
      iconBg:    "var(--color-zs-blue-dim)",
    },
    {
      label: "Ingresos del mes",
      value: formatCurrency(metrics?.monthlyRevenue ?? 0),
      icon:  DollarSign,
      trend: "+18% vs anterior",
      up:    true,
      accent: "em",
      iconColor: "var(--color-zs-emerald)",
      iconBg:    "var(--color-zs-em-dim)",
    },
    {
      label: "Tasa de asistencia",
      value: `${metrics?.attendanceRate ?? 0}%`,
      icon:  CheckCircle,
      trend: "Promedio óptimo",
      up:    true,
      accent: "cyan",
      iconColor: "var(--color-zs-cyan)",
      iconBg:    "var(--color-zs-cyan-dim)",
    },
    {
      label: "Top servicio",
      value: metrics?.topService ?? "—",
      icon:  Star,
      trend: "Más reservado",
      up:    true,
      accent: "amber",
      iconColor: "var(--color-zs-amber)",
      iconBg:    "var(--color-zs-amb-dim)",
      small:  true,
    },
  ];

  return (
    <div className="p-6 space-y-6 zs-stagger">

      {/* Header */}
      <header className="flex items-end justify-between zs-animate-up">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <div className="w-1.5 h-1.5 rounded-full zs-pulse-dot"
              style={{ background: "var(--color-zs-emerald)" }} />
            <span className="text-xs font-semibold tracking-widest uppercase"
              style={{ color: "var(--color-zs-emerald)" }}>Datos en tiempo real</span>
          </div>
          <h1 className="zs-text-display text-2xl font-black tracking-tight text-white">
            Resumen del Negocio
          </h1>
          <p className="text-sm mt-0.5" style={{ color: "var(--color-zs-text-muted)" }}>
            {new Date().toLocaleDateString("es-CR", { weekday: "long", month: "long", day: "numeric" })}
          </p>
        </div>
        <Link href="/tenant/calendario" className="zs-btn gap-2 text-sm">
          <CalendarDays className="w-4 h-4" /> Ver agenda
        </Link>
      </header>

      {/* KPI Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4 zs-animate-up"
        style={{ animationDelay: "0.05s" }}>
        {kpis.map(({ label, value, icon: Icon, trend, up, accent, iconColor, iconBg, small }) => (
          <div key={label}
            className={`zs-card zs-kpi-accent ${accent} p-5 !rounded-2xl`}
            style={{ position: "relative" }}>
            <div className="flex items-start justify-between mb-3">
              <p className="text-[10px] font-bold tracking-widest uppercase"
                style={{ color: "var(--color-zs-text-muted)" }}>
                {label}
              </p>
              <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                style={{ background: iconBg }}>
                <Icon className="w-4 h-4" style={{ color: iconColor }} />
              </div>
            </div>
            <p className={`zs-text-display font-black tracking-tight text-white mb-3 ${small ? "text-lg" : "text-3xl"}`}>
              {value}
            </p>
            <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-1 rounded-lg"
              style={up
                ? { background: "var(--color-zs-em-dim)", color: "var(--color-zs-emerald)" }
                : { background: "var(--color-zs-rose-dim)", color: "var(--color-zs-rose)" }}>
              {up ? <TrendingUp className="w-3 h-3" /> : "→"} {trend}
            </span>
          </div>
        ))}
      </div>

      {/* Appointments table */}
      <div className="zs-panel overflow-hidden zs-animate-up relative" style={{ animationDelay: "0.1s", position: "relative" }}>
        <div className="flex items-center justify-between p-5"
          style={{ borderBottom: "1px solid var(--color-zs-border)" }}>
          <div>
            <h3 className="zs-text-display font-bold text-base text-white">Próximas citas</h3>
            <p className="text-xs mt-0.5" style={{ color: "var(--color-zs-text-muted)" }}>
              Desde hoy en adelante
            </p>
          </div>
          <Link href="/tenant/calendario"
            className="flex items-center gap-1 text-xs font-semibold transition-colors"
            style={{ color: "var(--color-zs-blue-light)" }}>
            Ver calendario <ArrowRight className="w-3.5 h-3.5" />
          </Link>
        </div>

        {appointments.length > 0 ? (
          <div className="overflow-x-auto">
            <table className="zs-table">
              <thead>
                <tr>
                  <th>Cliente</th>
                  <th>Servicio</th>
                  <th>Fecha y hora</th>
                  <th>Estado</th>
                </tr>
              </thead>
              <tbody>
                {appointments.map((appt: any) => {
                  const cfg = STATUS_CONFIG[appt.status] ?? STATUS_CONFIG.PENDING;
                  const initials = appt.client.name.split(" ").map((n: string) => n[0]).slice(0, 2).join("").toUpperCase();

                  const avatarColors = [
                    { bg: "var(--color-zs-blue-dim)",  color: "var(--color-zs-blue-light)" },
                    { bg: "var(--color-zs-vio-dim)",   color: "var(--color-zs-violet)" },
                    { bg: "var(--color-zs-em-dim)",    color: "var(--color-zs-emerald)" },
                    { bg: "var(--color-zs-amb-dim)",   color: "var(--color-zs-amber)" },
                    { bg: "var(--color-zs-cyan-dim)",  color: "var(--color-zs-cyan)" },
                  ];
                  const av = avatarColors[appt.clientId.charCodeAt(0) % avatarColors.length];

                  return (
                    <tr key={appt.id}>
                      <td>
                        <div className="flex items-center gap-3">
                          <div className="w-8 h-8 rounded-lg flex items-center justify-center zs-text-display text-xs font-black flex-shrink-0"
                            style={{ background: av.bg, color: av.color }}>
                            {initials}
                          </div>
                          <div>
                            <p className="font-semibold text-white text-sm">{appt.client.name}</p>
                            <p className="text-xs" style={{ color: "var(--color-zs-text-muted)" }}>
                              {appt.client.email ?? appt.client.phone ?? "—"}
                            </p>
                          </div>
                        </div>
                      </td>
                      <td>
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold"
                          style={{ background: "var(--color-zs-blue-dim)", color: "var(--color-zs-blue-light)", border: "1px solid rgba(37,99,235,0.15)" }}>
                          ✂️ {appt.service.name}
                        </span>
                      </td>
                      <td>
                        <div className="flex items-center gap-1.5">
                          <Clock className="w-3 h-3" style={{ color: "var(--color-zs-text-muted)" }} />
                          <span className="zs-text-display font-bold text-sm text-white">
                            {formatTime(appt.date)}
                          </span>
                          <span className="text-xs ml-1" style={{ color: "var(--color-zs-text-muted)" }}>
                            {new Date(appt.date).toLocaleDateString("es-CR", { month: "short", day: "numeric" })}
                          </span>
                        </div>
                      </td>
                      <td>
                        <span className="zs-badge"
                          style={{ background: cfg.bg, color: cfg.color, border: `1px solid ${cfg.border}` }}>
                          <span className="w-1.5 h-1.5 rounded-full bg-current" />
                          {cfg.label}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="py-16 text-center">
            <CalendarDays className="w-10 h-10 mx-auto mb-3 opacity-20" />
            <p className="text-sm mb-4" style={{ color: "var(--color-zs-text-muted)" }}>
              No hay citas programadas próximamente.
            </p>
            <Link href="/tenant/calendario" className="zs-btn text-sm px-4 py-2 gap-2">
              <CalendarDays className="w-4 h-4" /> Crear primera cita
            </Link>
          </div>
        )}
      </div>

    </div>
  );
}
