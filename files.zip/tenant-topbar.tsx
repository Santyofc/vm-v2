"use client";

import { usePathname } from "next/navigation";
import { useSession } from "next-auth/react";
import { Bell, Search } from "lucide-react";

const TITLES: Record<string, string> = {
  "/":                  "Dashboard",
  "/calendario":        "Calendario",
  "/clientes":          "Clientes",
  "/servicios":         "Servicios",
  "/suscripciones":     "Facturación y Plan",
  "/configuracion":     "Configuración",
};

export function TenantTopbar() {
  const pathname  = usePathname();
  const { data: session } = useSession();
  const tenant    = (session?.user as any)?.tenantName ?? "Mi Negocio";
  const pageTitle = TITLES[pathname] ?? pathname.split("/").pop() ?? "Panel";

  return (
    <header className="zs-topbar">
      <div>
        <p
          className="text-[11px] font-medium"
          style={{ color: "var(--color-zs-text-muted)" }}
        >
          {tenant}
        </p>
        <h2 className="zs-text-display font-bold text-[15px] text-white">
          {pageTitle}
        </h2>
      </div>

      <div className="flex items-center gap-3">
        {/* Search */}
        <div
          className="hidden md:flex items-center gap-2 px-3 py-2 rounded-xl"
          style={{
            background: "var(--color-zs-surface)",
            border: "1px solid var(--color-zs-border)",
            width: 200,
          }}
        >
          <Search
            className="w-3.5 h-3.5 flex-shrink-0"
            style={{ color: "var(--color-zs-text-muted)" }}
          />
          <input
            placeholder="Buscar clientes..."
            className="text-sm bg-transparent outline-none w-full"
            style={{
              color: "var(--color-zs-text)",
              fontFamily: "var(--font-body)",
            }}
          />
        </div>

        {/* Bell */}
        <button
          className="w-9 h-9 rounded-xl flex items-center justify-center relative transition-all"
          style={{
            background: "var(--color-zs-surface)",
            border: "1px solid var(--color-zs-border)",
          }}
        >
          <Bell
            className="w-4 h-4"
            style={{ color: "var(--color-zs-text-muted)" }}
          />
          <span
            className="absolute top-1.5 right-1.5 w-2 h-2 rounded-full"
            style={{
              background: "var(--color-zs-blue)",
              border: "1.5px solid var(--color-zs-base)",
            }}
          />
        </button>

        {/* Avatar */}
        <div
          className="flex items-center gap-2.5 pl-3"
          style={{ borderLeft: "1px solid var(--color-zs-border)" }}
        >
          <div className="hidden sm:block text-right">
            <p className="text-sm font-semibold text-white">
              {session?.user?.name ?? "Usuario"}
            </p>
            <p
              className="text-[10px] font-bold tracking-widest uppercase"
              style={{ color: "var(--color-zs-cyan)" }}
            >
              {tenant}
            </p>
          </div>
          <div
            className="w-8 h-8 rounded-lg flex items-center justify-center zs-text-display font-black text-sm"
            style={{
              background: "var(--color-zs-blue)",
              boxShadow: "var(--shadow-blue)",
            }}
          >
            {session?.user?.name?.[0] ?? "U"}
          </div>
        </div>
      </div>
    </header>
  );
}
